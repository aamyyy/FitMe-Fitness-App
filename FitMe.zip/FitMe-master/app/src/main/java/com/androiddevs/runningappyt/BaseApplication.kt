package com.androiddevs.runningappyt

import android.app.Application
import com.androiddevs.runningappyt.core.SharedPreferencesManager
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber

@HiltAndroidApp
class BaseApplication: Application() {

    override fun onCreate() {
        super.onCreate()
        SharedPreferencesManager.instance.init(this)
        Timber.plant(Timber.DebugTree())
    }
}