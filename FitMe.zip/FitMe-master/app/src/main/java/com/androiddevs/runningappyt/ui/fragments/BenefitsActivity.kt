package com.androiddevs.runningappyt.ui.fragments

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.androiddevs.runningappyt.R
import kotlinx.android.synthetic.main.activity_info.*

class BenefitsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_benefits)
    }
}