package com.androiddevs.runningappyt.ui.fragments

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.androiddevs.runningappyt.R
import kotlinx.android.synthetic.main.activity_info.*

class ActivityInfo : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_info)

        benefits.setOnClickListener {
            val intent = Intent(this@ActivityInfo,BenefitsActivity::class.java)
            startActivity(intent)
        }
    }
}